package com.wolfbe.distributedid.core;

/**
 * @author Andy
 */
public interface Server {

    void start();

    void shutdown();
}
